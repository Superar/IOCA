python3 solver.py .\data\fl_25_2
python3 solver.py .\data\fl_50_6
python3 solver.py .\data\fl_100_1
python3 solver.py .\data\fl_100_7
python3 solver.py .\data\fl_200_7
python3 solver.py .\data\fl_500_7
python3 solver.py .\data\fl_1000_2
python3 solver.py .\data\fl_2000_2
